const nameSpaceA = {};
nameSpaceA.name = nameSpaceB.name + "!";
