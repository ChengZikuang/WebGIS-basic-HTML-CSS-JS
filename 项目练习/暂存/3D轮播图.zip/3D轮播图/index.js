//实现一个方法 让每张图片调整到对应的位置
let curIndex = 0; //图片的索引值 确认当前处于视口中心的那种图片
const xoffSet = 50; //x轴的偏移量
const scaleSpeed = 0.8; //缩放的速度
const rotateSpeed = 46; //y轴旋转的速度
const opacitySpeed = 0.6; //透明度的变化速度
const imgs = document.querySelectorAll("img");
function layout() {
  //1.让所有的图片叠在一起 处于视口中心
  //2.确定每一张图片去到什么位置 无非就是 确定每张图片 要 平移多少 旋转多少 透明度设置多少 缩放多少
  imgs.forEach((img, index) => {
    //x轴的偏移量
    let x = (index - curIndex) * xoffSet + Math.sign(index - curIndex) * 300;
    //希望让当前CurIndex这张图片的z-index值是最大的
    //index - curIndex 越小 说明这张图片应该处以顶层
    let zIndex = 100 - Math.abs(index - curIndex);
    //scale的变化速率
    let scale = Math.pow(scaleSpeed, Math.abs(index - curIndex));
    //rotateY的旋转变化速率
    let rotateY = Math.sign(index - curIndex) * rotateSpeed;
    //opacity透明度的变化
    let opacity = Math.pow(opacitySpeed, Math.abs(index - curIndex));
    img.style.zIndex = zIndex;
    img.style.transform = `translateX(${x}px)  scale(${scale}) rotateY(${rotateY}deg)`;
    img.style.opacity = opacity;
  });
}
layout();
imgs.forEach((img, index) => {
  img.addEventListener("click", function () {
    curIndex = index;
    layout();
  });
});
