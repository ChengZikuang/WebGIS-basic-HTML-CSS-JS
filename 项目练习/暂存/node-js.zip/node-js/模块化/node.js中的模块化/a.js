const name = "peiqi";
function fn() {
  console.log(name);
}
module.exports = {
  name,
  fn,
};
