const { name: aName ,fn} = require("./a.js");
const { name: bName } = require("./b.js");
// console.log(aName, bName);
fn()
