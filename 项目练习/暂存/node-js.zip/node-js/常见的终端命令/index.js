//node环境中书写的js代码跟之前是一样的
// dir展示当前的文件目录 
// cd 进入指定的目录
// echo xxx > 文件名称 来创建文件
// rm xxx 删除指定的文件
// mkdir xxx 创建文件目录
// rm -rf xxx 删除指定的文件目录 rmdir
// cls清空命令行
// 通过上下箭头来快速查询之前输入过的命令
console.log('node.js')