const nameSpaceB = {};
nameSpaceB.name = "qiaozhi";
